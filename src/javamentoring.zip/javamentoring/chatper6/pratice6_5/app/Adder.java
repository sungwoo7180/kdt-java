package javamentoring.chatper6.pratice6_5.app;

public class Adder {

    private int x,y;
    public Adder(int x, int y) {
        this.x=x;
        this.y=y;
    }
    public int add() {
        return x+y;
    }

}