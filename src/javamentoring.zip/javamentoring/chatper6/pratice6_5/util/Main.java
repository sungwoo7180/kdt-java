package javamentoring.chatper6.pratice6_5.util;
import javamentoring.chatper6.pratice6_5.app.*;

public class Main {
    public static void main(String[] args) {
        Adder adder = new Adder(2,5);
        System.out.println(adder.add());
    }
}
