package javamentoring.chatper6;

//import java.util.Scanner;
//import java.util.StringTokenizer;

public class Theory6_2 {
    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        StringTokenizer st = new StringTokenizer(scanner.nextLine(), "/");
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        java.util.StringTokenizer st = new java.util.StringTokenizer(scanner.nextLine(), "/");
        while(st.hasMoreTokens())
            System.out.println(st.nextToken());

    }
}
